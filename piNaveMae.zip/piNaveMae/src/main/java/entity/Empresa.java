package entity;

import javax.persistence.*;

@Entity

public class Empresa {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column
    private String nome;

    // seguimento conversar com grupo , se e nescessario

    //contato n�o entendi acho que e email ou telefone ???
    @Column
    private Long cnpj;

    @Column
    private Integer telefone;

    @Column
    private  String site;

    //  fazer liga��o de endere�o com a classe cidade <<<
    @JoinColumn(name = "id_evento")
    @OneToOne
    private Evento evento;

    public Empresa(String nome, Long cnpj, Integer telefone, String site, Evento evento) {
        this.nome = nome;
        this.cnpj = cnpj;
        this.telefone = telefone;
        this.site = site;
        this.evento = evento;
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) {
        this.evento = evento;
    }

    public Empresa() {

        //contrutor vazio
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Long getCnpj() {
        return cnpj;
    }

    public void setCnpj(Long cnpj) {
        this.cnpj = cnpj;
    }

    public Integer getTelefone() {
        return telefone;
    }

    public void setTelefone(Integer telefone) {
        this.telefone = telefone;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }
}
