package entity;

import javax.persistence.*;
import java.util.Date;

@Entity
public class Evento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column
    @Temporal(TemporalType.DATE)
    private Date dataEvento;
    //  Hora vai ser junto var como adicionar hora <<<<< DateTime

    //carga horaria da ativida descobrir como fazer >>>>> tem que ter uma logica<<<<

    @Column
    private String assunto;

    //  Lugar e uma cidade na classe cidade !!1
    @Column
    private Integer capacidade;

    @Column
    private Double valor;

    @JoinColumn(name = "id_pessoa")
    @ManyToOne
    private Pessoa pessoa; // fazer lista de pessoas




    public Evento(Date dataEvento, String assunto, Integer capacidade, Double valor, Pessoa pessoa) {
        this.dataEvento = dataEvento;
        this.assunto = assunto;
        this.capacidade = capacidade;
        this.valor = valor;
        this.pessoa = pessoa;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    public Evento() {

        //contrutor vazio
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDataEvento() {
        return dataEvento;
    }

    public void setDataEvento(Date dataEvento) {
        this.dataEvento = dataEvento;
    }

    public String getAssunto() {
        return assunto;
    }

    public void setAssunto(String assunto) {
        this.assunto = assunto;
    }

    public Integer getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(Integer capacidade) {
        this.capacidade = capacidade;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }
}
