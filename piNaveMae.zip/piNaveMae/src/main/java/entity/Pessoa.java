package entity;

import javax.persistence.*;

@Entity



public class Pessoa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column
    private String nome;

    @Column
    private Integer telefone;

    @Column
    private String email;

    @Column
    private Boolean estudante;


    // institui��o precisa ser feito uma nova classe.

   // @Column
   // private nivel  entender como usar , combobox

    // Curso vai ser atributo da classe institui��o

    // cidade vai ser uma classe

    // senha estudar como fazer
    // senha estudar como fazer


    // horas a comprir estudar tbm como fazer


    public Pessoa(String nome, Integer telefone, String email, Boolean estudante) {
        this.nome = nome;
        this.telefone = telefone;
        this.email = email;
        this.estudante = estudante;
    }

    public Pessoa() {
        //contrutor vazio
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getTelefone() {
        return telefone;
    }

    public void setTelefone(Integer telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Boolean getEstudante() {
        return estudante;
    }

    public void setEstudante(Boolean estudante) {
        this.estudante = estudante;
    }
}
